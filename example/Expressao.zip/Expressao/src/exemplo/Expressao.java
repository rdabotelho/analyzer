package exemplo;

import com.rim.analyzer.Analyzer;
import com.rim.analyzer.AnalyzerFactory;
import com.rim.analyzer.comp.TypeSupporter;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Expressao {
    
    public static void main(String[] args){
        System.out.println("Entre com uma expressão aritmética: ");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in)); 
            Analyzer analyzer = AnalyzerFactory.createAnalyzer("src/resources/def-expr.xml");
            analyzer.scanner(new StringBuffer(in.readLine()));
            analyzer.parse();
            TypeSupporter resultado = analyzer.compute();
            System.out.println("O resultado da expressão é " + resultado.toString()+"\n");
        }
        catch(Exception e){
            e.printStackTrace();
        }                
    }
}
