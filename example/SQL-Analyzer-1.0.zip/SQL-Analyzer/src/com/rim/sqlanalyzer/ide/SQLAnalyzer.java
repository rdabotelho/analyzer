/*
 * LisimIDE.java
 *
 * Created on 2 de Novembro de 2007, 15:10
 */

package com.rim.sqlanalyzer.ide;

import com.rim.sqlanalyzer.ide.*;
import java.awt.Color;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JApplet;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.text.TabSet;
import javax.swing.text.TabStop;




/**
 *
 * @author  Raimundo Botelho
 */
public class SQLAnalyzer extends JApplet {
    
    private int posicaoCaret = 0;
    
    private String caminhoSelecionado = ".";
    private boolean alterado = false;
    private IDEState stIDE = IDEState.EMPTY;
    private FileState stArquivo = FileState.NOTHING;
    
    private File arquivoSelecionado;
    private static final int MAX_CONTAGEM = 2;
    private int contagem = MAX_CONTAGEM;
    private static final String PATTERN_COMMENT = "(/\\*(.|\\n)*?\\*/)";
    private static final String PATTERN_LOGIC = "(?i)(AND|OR|NOT)";
    private static final String PATTERN_KEY_WORDS = "(?i)(PRIMARY|POSITION|BETWEEN|HAVING|COLUMN|WHERE|LIKE|ALTER|TABLE|SELECT|DELETE|SMALLINT|INTEGER|DECIMAL|NUMERIC|DOUBLE|DEFAULT|PRECISION|DISTINCT|INSERT|VALUES|UPDATE|CREATE|TABLE|FROM|REAL|FLOAT|CHAR|VARCHAR|GROUP|ORDER|INTO|TYPE|DROP|SET|ADD|AS|IS|BY|NULL|KEY|IN|TO)";
    private static final String PATTERN_REAL = "([0-9]+(\\.[0-9]+))";
    private static final String PATTERN_INTEGER = "([0-9]+)";
    private static final String PATTERN_STRING = "(\\Q'\\E(\\Q\\'\\E|[.&[^\\n\\Q\\'\\E]])*?\\Q'\\E)";
    private String lookAndFeel = "javax.swing.plaf.metal.MetalLookAndFeel";
    private int inactiveEditorTime;
    private MyAppender appender;
    private SQL sql;
    
    public SQLAnalyzer(){   
    }

    public void init(){        
        // inicia janela
        initComponents();
        populaArvore();
        try {
            iniciar();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }
        rgmCrossPlatform.doClick();
        setVisible(true);
    }
    
    private void iniciar() throws Exception{
        appender = new MyAppender(jTextAreaExecucao);
        sql = new SQL(appender);
        definirEstilos();        
        new Thread(){
            public void run(){
                while(true){
                    btnNovo.setEnabled(stIDE != IDEState.EXECUTING);
                    btnAbrir.setEnabled(stIDE != IDEState.EXECUTING);
                    btnSalvar.setEnabled(stIDE == IDEState.OPENED && stArquivo == FileState.SAVED && alterado);
                    btnSalvarComo.setEnabled(stIDE == IDEState.OPENED);
                    btnExecutar.setEnabled(stIDE == IDEState.OPENED);
                    btnParar.setEnabled(stIDE == IDEState.EXECUTING);
                    txpCodigo.setVisible(stIDE != IDEState.EMPTY);
                    
                    mitNovo.setEnabled(btnNovo.isEnabled());
                    mitAbrir.setEnabled(btnAbrir.isEnabled());
                    mitSalvar.setEnabled(btnSalvar.isEnabled());
                    mitSalvarComo.setEnabled(btnSalvarComo.isEnabled());
                    mitExecutar.setEnabled(btnExecutar.isEnabled());
                    mitParar.setEnabled(btnParar.isEnabled());
                    
                    mostarLinhaEPosicao();
                    try{
                        Thread.sleep(1000);
                    }
                    catch(InterruptedException e){                        
                    }
                }
            }
        }.start();
    }

    private void mostarLinhaEPosicao(){
        if(stIDE == IDEState.OPENED && txpCodigo.getCaret() != null){
            if(posicaoCaret != txpCodigo.getCaret().getDot()){
                posicaoCaret = txpCodigo.getCaret().getDot();
                try{
                    String parte = txpCodigo.getDocument().getText(0,posicaoCaret);
                    int posicao = parte.length()+1;
                    int linha = 1;
                    int tmp = 0;
                    while((tmp = parte.indexOf('\n',tmp+1)) > -1){
                        linha++;
                        posicao = parte.length() - tmp;
                    }    
                    lblStatus.setText("Linha: "+linha+"   -   Posi��o: "+posicao);
                }
                catch(Exception e){                    
                }
            }
        }
        else
            lblStatus.setText("Linha: 0   -   Posi��o: 0");
    }
    
    private void populaArvore(){
        try{
            popularArvoreComJar();
        }
        catch(Exception e){
            String path = getClass().getResource("SQLAnalyzer.class").getPath().replaceAll("SQLAnalyzer.class","")+"../../../../exemplos";
            File file = new File(path);
            jTreeArquivos.setModel(new MyTreeModel(new NodoExemploFile(file)));
        }        
    }

    private void popularArvoreComJar() throws IOException{
        URL url = getClass().getResource("/com/rim/sqlanalyzer");
        JarURLConnection connection = (JarURLConnection)url.openConnection();
        JarFile jarFile = connection.getJarFile();
        Enumeration<JarEntry> jarEntries = jarFile.entries();        
        Map<String,NodoExemploJar> nodos = new HashMap<String,NodoExemploJar>();
        NodoExemploJar raiz = null;
        while(jarEntries.hasMoreElements()){
            JarEntry je = jarEntries.nextElement();
            if(!je.getName().startsWith("exemplos"))
                continue;
            String[] caminho = je.getName().split("/");
            NodoExemploJar pai = null;
            if(caminho.length > 1){
                StringBuffer nomePai = new StringBuffer();
                for(int i=0; i<(caminho.length-1); i++)
                    nomePai.append(caminho[i]+"/");
                pai = nodos.get(nomePai.toString());
            }                
            NodoExemploJar nodo = new NodoExemploJar(pai,jarFile,je.getName(),caminho[caminho.length-1]);
            nodos.put(je.getName(),nodo);
            if(raiz == null)
                raiz = nodo;
        }
        jTreeArquivos.setModel(new MyTreeModel(raiz));
    }
    
    private void definirEstilos(){
        Style defaultStyle = txpCodigo.getStyle(StyleContext.DEFAULT_STYLE);
	TabStop tabs[] = new TabStop[150];
	for (int i = 0; i < 150; i++)
            tabs[i] = new TabStop(20+i*20, TabStop.ALIGN_LEFT, TabStop.LEAD_NONE);
	TabSet t = new TabSet(tabs);
	StyleConstants.setTabSet(defaultStyle, t);
	StyleConstants.setFontFamily(defaultStyle, "Monospaced");
	StyleConstants.setFontSize(defaultStyle, 12);

	//Desconhecido
	Style style = txpCodigo.addStyle("unknow", null);
	StyleConstants.setForeground(style, Color.BLACK);
	StyleConstants.setBold(style, false);
	    
	//Coment�rio
	style = txpCodigo.addStyle("comment", null);
	StyleConstants.setForeground(style, new Color(115,115,115));
	    
	//String
	style = txpCodigo.addStyle("string", null);
	StyleConstants.setForeground(style, new Color(0,111,0));
	    
	//Operadores L�gicos
	style = txpCodigo.addStyle("logic", null);
	StyleConstants.setForeground(style, new Color(0,0,153));
	StyleConstants.setBold(style, true);

        //Palavra Reservada
	style = txpCodigo.addStyle("reserved", null);
	StyleConstants.setForeground(style, new Color(0,0,153));
	StyleConstants.setBold(style, true);
	    
	//Fun��o
	style = txpCodigo.addStyle("function", null);
	StyleConstants.setBold(style, true);

        //Real
	style = txpCodigo.addStyle("real", null);
	StyleConstants.setForeground(style, new Color(120,0,0));
	    
	//Inteiro
	style = txpCodigo.addStyle("integer", null);
	StyleConstants.setForeground(style, new Color(153,0,107));	    
    }
    
    private void iniciarContagem(){        
        zerarContagem();
        new Thread(){
            public void run(){
                 zerarContagem();
                 while(contagem < MAX_CONTAGEM){
                     contagem++;
                     try {
                         Thread.sleep(500);
                     }
                     catch(Exception e){                            
                     }
                 }
                 aplicarLayout();
             }
        }.start();
    }

    private void reiniciarContagem(){
        if(contagem == MAX_CONTAGEM)
            iniciarContagem();
        else
            zerarContagem();
    }
    
    private void zerarContagem(){
        contagem = 0;
    }

    private void pararContagem(){
        contagem = MAX_CONTAGEM;
    }

    private void aplicarLayout(){
        StyledDocument doc = txpCodigo.getStyledDocument();
        doc.setCharacterAttributes(0,doc.getLength(),txpCodigo.getStyle("unknow"),true);
        String ER = PATTERN_COMMENT+"|"+
                    PATTERN_STRING+"|"+                    
                    PATTERN_KEY_WORDS+"|"+
                    PATTERN_LOGIC+"|"+
                    PATTERN_REAL+"|"+
                    PATTERN_INTEGER+"|"+
                    "(\\n|\\r)";
        Pattern p = Pattern.compile(ER,Pattern.DOTALL);
        Matcher m = p.matcher(txpCodigo.getText());        
        int breakLine = 0;
        while(m.find()){
            int pos = m.start() - breakLine;
            String lexema = m.group();
            int tam = lexema.length();
            if(Pattern.matches(PATTERN_COMMENT,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("comment"), true);
            else if(Pattern.matches(PATTERN_LOGIC,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("logic"), true);
            else if(Pattern.matches(PATTERN_KEY_WORDS,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("reserved"), true);
            else if(Pattern.matches(PATTERN_REAL,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("real"), true);
            else if(Pattern.matches(PATTERN_INTEGER,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("integer"), true);
            else if(Pattern.matches(PATTERN_STRING,lexema))
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("string"), true); 
            else if (Pattern.matches("(\\r)",lexema))
                breakLine++;
            else    
                doc.setCharacterAttributes(pos, tam, txpCodigo.getStyle("unknow"), true); 
        }
    }
    
    private void novoArquivo(){
        if(alterado){            
            int opc = JOptionPane.showConfirmDialog(null,"Deseja salvar o c�digo fonte?","Salvar c�digo fonte",JOptionPane.YES_NO_CANCEL_OPTION);
            if(opc == JOptionPane.YES_OPTION)
                salvarComoArquivo();
            else if(opc == JOptionPane.CANCEL_OPTION)
                return;
        }            
        txpCodigo.setText("");
        stIDE = IDEState.OPENED;
        stArquivo = FileState.NEW;
        alterado = false;
    }
    
    private void fecharArquivo(){
        stIDE = IDEState.EMPTY;
        stArquivo = FileState.NOTHING;
        txpCodigo.setVisible(false);
        arquivoSelecionado = null;
    }
    
    private void abrirArquivo(){
        JFileChooser fileChooser = null;
        try{
        fileChooser = new JFileChooser(caminhoSelecionado);
        }
        catch(Exception e){
            txpCodigo.setText(e.toString());
        }
        fileChooser.setDialogTitle("Abrir Arquivo");
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(new FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() | f.getName().endsWith(".sql");
            }
            public String getDescription() {
                return "C�digo Fonte SQL";
            }
        });
        if(fileChooser.showOpenDialog(new Frame()) == JFileChooser.APPROVE_OPTION){
            File file = fileChooser.getSelectedFile();
            abrirArquivo(file);
            stArquivo = FileState.SAVED;
            caminhoSelecionado = fileChooser.getCurrentDirectory().getPath();
        }
    }
    
    private void abrirArquivo(File file){
        try {
            byte[] dados = new byte[(int)file.length()];
            FileInputStream in = new FileInputStream(file);
            in.read(dados);
            in.close();
            abrirCodigoFonte(new String(dados));
            arquivoSelecionado = file;
            aplicarLayout();
            stIDE = IDEState.OPENED;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Erro na leitura do arquivo\n"+e.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }        
    }    
    
    private void abrirCodigoFonte(String codigoFonte){
        arquivoSelecionado = null;
        txpCodigo.setText(codigoFonte);
        aplicarLayout();
        stIDE = IDEState.OPENED;
    }
    
    private void salvarArquivo(){
        if(stArquivo == FileState.NEW)
            salvarComoArquivo();
        else
            salvarComoArquivo(arquivoSelecionado);
    }

    private void salvarComoArquivo(){
        JFileChooser fileChooser = new JFileChooser(caminhoSelecionado);
        fileChooser.setDialogTitle("Salvar Arquivo");
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(new FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() | f.getName().endsWith(".sql");
            }
            public String getDescription() {
                return "C�digo Fonte SQL";
            }
        });
        if(fileChooser.showSaveDialog(new Frame()) == JFileChooser.APPROVE_OPTION){
            String fileName = fileChooser.getSelectedFile().toString();
            if(!fileName.toUpperCase().endsWith(".SQL"))
                fileName += ".sql";
            File file = new File(fileName);    
            salvarComoArquivo(file);            
            caminhoSelecionado = fileChooser.getCurrentDirectory().getPath();
        }
    }    
    
    private void salvarComoArquivo(File file){
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(txpCodigo.getText());
            writer.close();
            stIDE = IDEState.OPENED;
            stArquivo = FileState.SAVED;
            alterado = false;
            arquivoSelecionado = file;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Erro ao salvar o arquivo\n"+e.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
        }        
    }
    
    private void executar(){
        jTabbedPane1.setSelectedIndex(1);
        stIDE = IDEState.EXECUTING;
        new Thread(){
            public void run(){
                sql.execute(txpCodigo.getText());
                jTextAreaExecucao.setCaretPosition(jTextAreaExecucao.getText().length());
                stIDE = IDEState.OPENED;
            }
        }.start();
    }
    
    public void parar(){
        stIDE = IDEState.OPENED;        
        appender.interrupt();
    }
    
    /** This method is called from within the init() method to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTreeArquivos = new javax.swing.JTree();
        jScrollPane2 = new javax.swing.JScrollPane();
        txpCodigo = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextAreaExecucao = new javax.swing.JTextArea();
        lblStatus = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jToolBar1 = new javax.swing.JToolBar();
        btnNovo = new javax.swing.JButton();
        btnAbrir = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnSalvarComo = new javax.swing.JButton();
        jToolBar2 = new javax.swing.JToolBar();
        btnExecutar = new javax.swing.JButton();
        btnParar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        menArquivos = new javax.swing.JMenu();
        mitNovo = new javax.swing.JMenuItem();
        mitAbrir = new javax.swing.JMenuItem();
        mitFechar = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        mitSalvar = new javax.swing.JMenuItem();
        mitSalvarComo = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        mitSair = new javax.swing.JMenuItem();
        menInterpretador = new javax.swing.JMenu();
        mitExecutar = new javax.swing.JMenuItem();
        mitParar = new javax.swing.JMenuItem();
        menLookAndFeel = new javax.swing.JMenu();
        rgmSystem = new javax.swing.JRadioButtonMenuItem();
        rgmCrossPlatform = new javax.swing.JRadioButtonMenuItem();
        menAjuda = new javax.swing.JMenu();
        mitSobre = new javax.swing.JMenuItem();

        jPanel2.setLayout(new java.awt.BorderLayout());

        jTreeArquivos.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                jTreeArquivosValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jTreeArquivos);

        jSplitPane1.setLeftComponent(jScrollPane1);

        txpCodigo.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txpCodigoCaretUpdate(evt);
            }
        });
        txpCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txpCodigoKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(txpCodigo);

        jSplitPane1.setRightComponent(jScrollPane2);

        jPanel2.add(jSplitPane1, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("C\u00f3digo Fonte", jPanel2);

        jPanel3.setLayout(new java.awt.BorderLayout());

        jTextAreaExecucao.setColumns(20);
        jTextAreaExecucao.setFont(new java.awt.Font("Courier New", 0, 12));
        jTextAreaExecucao.setRows(5);
        jTextAreaExecucao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextAreaExecucaoKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextAreaExecucaoKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextAreaExecucaoKeyTyped(evt);
            }
        });
        jTextAreaExecucao.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                jTextAreaExecucaoCaretUpdate(evt);
            }
        });
        jScrollPane3.setViewportView(jTextAreaExecucao);

        jPanel3.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Execu\u00e7\u00e3o", jPanel3);

        getContentPane().add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        lblStatus.setText("Linha: 0   -   Posi\u00e7\u00e3o: 0");
        getContentPane().add(lblStatus, java.awt.BorderLayout.SOUTH);

        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        btnNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/new.png"))); // NOI18N
        btnNovo.setToolTipText("Cria um novo arquivo sql");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });
        jToolBar1.add(btnNovo);

        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/open.png"))); // NOI18N
        btnAbrir.setToolTipText("Abre um arquivo sql");
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        jToolBar1.add(btnAbrir);

        btnSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/save.png"))); // NOI18N
        btnSalvar.setToolTipText("Salva um arquivo sql existente");
        btnSalvar.setEnabled(false);
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnSalvar);

        btnSalvarComo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/saveall.png"))); // NOI18N
        btnSalvarComo.setToolTipText("Salva um novo arquivo sql");
        btnSalvarComo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarComoActionPerformed(evt);
            }
        });
        jToolBar1.add(btnSalvarComo);

        jPanel1.add(jToolBar1);

        btnExecutar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/execute.png"))); // NOI18N
        btnExecutar.setToolTipText("Executa um arquivo sql");
        btnExecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExecutarActionPerformed(evt);
            }
        });
        jToolBar2.add(btnExecutar);

        btnParar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/stop.png"))); // NOI18N
        btnParar.setToolTipText("Para a execu\u00e7\u00e3o de um arquivo sql");
        btnParar.setEnabled(false);
        btnParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPararActionPerformed(evt);
            }
        });
        jToolBar2.add(btnParar);

        jPanel1.add(jToolBar2);

        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        menArquivos.setMnemonic('A');
        menArquivos.setText("Arquivo");
        menArquivos.setToolTipText("");

        mitNovo.setMnemonic('N');
        mitNovo.setText("Novo");
        mitNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitNovoActionPerformed(evt);
            }
        });
        menArquivos.add(mitNovo);

        mitAbrir.setMnemonic('b');
        mitAbrir.setText("Abrir...");
        mitAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitAbrirActionPerformed(evt);
            }
        });
        menArquivos.add(mitAbrir);

        mitFechar.setMnemonic('F');
        mitFechar.setText("Fechar");
        mitFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitFecharActionPerformed(evt);
            }
        });
        menArquivos.add(mitFechar);
        menArquivos.add(jSeparator2);

        mitSalvar.setMnemonic('S');
        mitSalvar.setText("Salvar");
        mitSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitSalvarActionPerformed(evt);
            }
        });
        menArquivos.add(mitSalvar);

        mitSalvarComo.setMnemonic('C');
        mitSalvarComo.setText("Salvar como...");
        mitSalvarComo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitSalvarComoActionPerformed(evt);
            }
        });
        menArquivos.add(mitSalvarComo);
        menArquivos.add(jSeparator1);

        mitSair.setMnemonic('r');
        mitSair.setText("Sair");
        mitSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitSairActionPerformed(evt);
            }
        });
        menArquivos.add(mitSair);

        jMenuBar1.add(menArquivos);

        menInterpretador.setMnemonic('I');
        menInterpretador.setText("Analisador");

        mitExecutar.setMnemonic('E');
        mitExecutar.setText("Executar");
        mitExecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitExecutarActionPerformed(evt);
            }
        });
        menInterpretador.add(mitExecutar);

        mitParar.setMnemonic('P');
        mitParar.setText("Parar");
        mitParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitPararActionPerformed(evt);
            }
        });
        menInterpretador.add(mitParar);

        jMenuBar1.add(menInterpretador);

        menLookAndFeel.setMnemonic('L');
        menLookAndFeel.setText("Look & Feel");

        rgmSystem.setMnemonic('S');
        rgmSystem.setText("System Look & Feel");
        rgmSystem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rgmSystemActionPerformed(evt);
            }
        });
        menLookAndFeel.add(rgmSystem);

        rgmCrossPlatform.setMnemonic('C');
        rgmCrossPlatform.setText("Cross Platform Look & Feel");
        rgmCrossPlatform.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rgmCrossPlatformActionPerformed(evt);
            }
        });
        menLookAndFeel.add(rgmCrossPlatform);

        jMenuBar1.add(menLookAndFeel);

        menAjuda.setMnemonic('j');
        menAjuda.setText("Ajuda");
        menAjuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menAjudaActionPerformed(evt);
            }
        });

        mitSobre.setMnemonic('S');
        mitSobre.setText("Sobre");
        mitSobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mitSobreActionPerformed(evt);
            }
        });
        menAjuda.add(mitSobre);

        jMenuBar1.add(menAjuda);

        setJMenuBar(jMenuBar1);
    }// </editor-fold>//GEN-END:initComponents

    private void rgmCrossPlatformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rgmCrossPlatformActionPerformed
        String laf = UIManager.getCrossPlatformLookAndFeelClassName();
        try{
            UIManager.setLookAndFeel(laf);
            SwingUtilities.updateComponentTreeUI(this);
            definirEstilos();
            rgmSystem.setSelected(false);
        }
        catch(Exception e){            
            JOptionPane.showMessageDialog(null,"Look And Feel n�o instalado","Erro",JOptionPane.ERROR_MESSAGE);
        }        
    }//GEN-LAST:event_rgmCrossPlatformActionPerformed

    private void rgmSystemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rgmSystemActionPerformed
        String laf = UIManager.getSystemLookAndFeelClassName();
        try{
            UIManager.setLookAndFeel(laf);
            SwingUtilities.updateComponentTreeUI(this);
            definirEstilos();
            rgmCrossPlatform.setSelected(false);
        }
        catch(Exception e){            
            JOptionPane.showMessageDialog(null,"Look And Feel n�o instalado","Erro",JOptionPane.ERROR_MESSAGE);
        }        
    }//GEN-LAST:event_rgmSystemActionPerformed

    private void txpCodigoCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txpCodigoCaretUpdate

    }//GEN-LAST:event_txpCodigoCaretUpdate

    private void mitSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitSobreActionPerformed
        JOptionPane.showMessageDialog(null,"SQL ANSI\n" +
                "Linguagem SQL B�sica\n\n" +
                "Centro Universit�rio do Estado do Par� � CESUPA\n" +
                "�rea de Ci�ncias Exatas e Tecnologia � ACET\n" +
                "Curso de Bacharelado em Ci�ncia da Computa��o\n\n" +
                "Alunos:\n" +
                "     Raimundo Botelho\n" +
                "     Israel Fran�a\n" +
                "     Michael Salzer\n\n" +
                "Orientador\n" +
                "     Ot�vio Noura");
    }//GEN-LAST:event_mitSobreActionPerformed

    private void menAjudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menAjudaActionPerformed

    }//GEN-LAST:event_menAjudaActionPerformed

    private void mitSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitSairActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_mitSairActionPerformed

    private void mitSalvarComoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitSalvarComoActionPerformed
        salvarComoArquivo();
    }//GEN-LAST:event_mitSalvarComoActionPerformed

    private void mitSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitSalvarActionPerformed
        salvarArquivo();
    }//GEN-LAST:event_mitSalvarActionPerformed

    private void mitAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitAbrirActionPerformed
        abrirArquivo();
    }//GEN-LAST:event_mitAbrirActionPerformed

    private void mitNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitNovoActionPerformed
        novoArquivo();
    }//GEN-LAST:event_mitNovoActionPerformed

    private void mitPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitPararActionPerformed
        parar();
    }//GEN-LAST:event_mitPararActionPerformed

    private void mitExecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitExecutarActionPerformed
        executar();
    }//GEN-LAST:event_mitExecutarActionPerformed

    private void mitFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mitFecharActionPerformed
        fecharArquivo();
    }//GEN-LAST:event_mitFecharActionPerformed

    private void btnSalvarComoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarComoActionPerformed
        salvarComoArquivo();
    }//GEN-LAST:event_btnSalvarComoActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        novoArquivo();
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        salvarArquivo();
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void txpCodigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txpCodigoKeyPressed
        if(evt.getKeyChar() != evt.CHAR_UNDEFINED){
            alterado = true;
            reiniciarContagem();
        }    
    }//GEN-LAST:event_txpCodigoKeyPressed

    private void btnPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPararActionPerformed
        parar();
    }//GEN-LAST:event_btnPararActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        abrirArquivo();
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnExecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExecutarActionPerformed
        executar();
    }//GEN-LAST:event_btnExecutarActionPerformed

    private void jTextAreaExecucaoCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_jTextAreaExecucaoCaretUpdate
    }//GEN-LAST:event_jTextAreaExecucaoCaretUpdate

    private void jTextAreaExecucaoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextAreaExecucaoKeyReleased
    }//GEN-LAST:event_jTextAreaExecucaoKeyReleased

    private void jTextAreaExecucaoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextAreaExecucaoKeyTyped
    }//GEN-LAST:event_jTextAreaExecucaoKeyTyped

    private void jTextAreaExecucaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextAreaExecucaoKeyPressed
        if(evt.getKeyChar() == '\n'){ 
            evt.consume();
            appender.setCanRead(true);
        }    
        else if(evt.getKeyChar()==evt.VK_BACK_SPACE)
            appender.deleteLastChar();
        else if(evt.getKeyChar() != evt.CHAR_UNDEFINED)
            appender.append(evt.getKeyChar());                 
    }//GEN-LAST:event_jTextAreaExecucaoKeyPressed

    private void jTreeArquivosValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_jTreeArquivosValueChanged
        NodoExemplo nodo = (NodoExemplo)evt.getPath().getPath()[evt.getPath().getPathCount()-1];
        if(nodo.eArquivo()){
            try {
                abrirCodigoFonte(nodo.getCodigoFonte());
                stArquivo = FileState.SELECTED;
                alterado = false;
                txpCodigo.setVisible(true);
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null,"Erro na leitura do arquivo\n"+e.getMessage(),"Erro",JOptionPane.ERROR_MESSAGE);
            }            
        } 
    }//GEN-LAST:event_jTreeArquivosValueChanged
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnExecutar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnParar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnSalvarComo;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextAreaExecucao;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JTree jTreeArquivos;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JMenu menAjuda;
    private javax.swing.JMenu menArquivos;
    private javax.swing.JMenu menInterpretador;
    private javax.swing.JMenu menLookAndFeel;
    private javax.swing.JMenuItem mitAbrir;
    private javax.swing.JMenuItem mitExecutar;
    private javax.swing.JMenuItem mitFechar;
    private javax.swing.JMenuItem mitNovo;
    private javax.swing.JMenuItem mitParar;
    private javax.swing.JMenuItem mitSair;
    private javax.swing.JMenuItem mitSalvar;
    private javax.swing.JMenuItem mitSalvarComo;
    private javax.swing.JMenuItem mitSobre;
    private javax.swing.JRadioButtonMenuItem rgmCrossPlatform;
    private javax.swing.JRadioButtonMenuItem rgmSystem;
    private javax.swing.JTextPane txpCodigo;
    // End of variables declaration//GEN-END:variables
    
}
enum FileState {
    NOTHING,NEW,SELECTED,SAVED
}

enum IDEState {
    EMPTY,OPENED,EXECUTING
}
