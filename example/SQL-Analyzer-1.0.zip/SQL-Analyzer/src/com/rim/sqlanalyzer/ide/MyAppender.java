/*
 * MyConsoleAppender.java
 *
 * Created on 2 de Novembro de 2007, 17:53
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

import com.rim.analyzer.Appender;
import java.io.IOException;
import javax.swing.JTextArea;

/**
 *
 * @author Raimundo Botelho
 */
public class MyAppender implements Appender {

    private StringBuffer buffer;
    private boolean canRead;
    private boolean interrupted;
    private JTextArea textArea;
    
    /** Creates a new instance of MyConsoleAppender */
    public MyAppender(JTextArea textArea) {
        this.interrupted = false;
        this.textArea = textArea;
    }
    
    public void interrupt(){
        this.interrupted = true;
    }
    
    public void print(String s) {
        textArea.append(s);
    }

    public void println() {
        textArea.append("\n");
    }

    public void println(String s) {
        textArea.append(s+"\n");
    }

    public String readln() throws IOException{
        setCanRead(false);
        textArea.setEditable(true);
        textArea.grabFocus();
        buffer = new StringBuffer();
        while(!canRead){
            try{
                if(this.interrupted)
                    throw new IOException("Execu��o interrompida pelo usu�rio");
                textArea.setCaretPosition(textArea.getText().length()-1);
                Thread.sleep(100);
            }
            catch(InterruptedException e){                
            }
        }    
        textArea.setEditable(false);        
        return buffer.toString();
    }

    public boolean isCanRead() {
        return canRead;
    }

    public void setCanRead(boolean canRead) {
        this.canRead = canRead;
    }
    
    public void append(char c){
        this.buffer.append(c);
    }
    
    public void deleteLastChar(){
        this.buffer.deleteCharAt(buffer.length()-1);
    }
}
