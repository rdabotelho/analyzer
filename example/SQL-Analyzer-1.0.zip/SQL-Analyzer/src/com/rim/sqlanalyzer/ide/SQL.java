/*
 * Lisim.java
 *
 * Created on 2 de Novembro de 2007, 17:20
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

import com.rim.analyzer.Analyzer;
import com.rim.analyzer.AnalyzerFactory;
import com.rim.analyzer.Appender;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

/**
 *
 * @author Raimundo Botelho
 */
public class SQL {
    
    private Analyzer analyzer;
    
    /** Creates a new instance of Lisim */
    public SQL(Appender appender) throws Exception {
        try {
            URL url = getClass().getResource("/com/rim/sqlanalyzer");
            JarURLConnection connection = (JarURLConnection)url.openConnection();
            JarFile jarFile = connection.getJarFile();
            ZipEntry zipEntry = jarFile.getEntry("com/rim/sqlanalyzer/ling/sql-definition.xml");
            InputStream in = jarFile.getInputStream(zipEntry);
            analyzer = AnalyzerFactory.createAnalyzer(in);
            analyzer.setAppender(appender);
            in.close();
        }
        catch(Exception e){
            String uri = getClass().getResource("../ling/sql-definition.xml").getPath();
            analyzer = AnalyzerFactory.createAnalyzer(uri);
            analyzer.setAppender(appender);
        }    
    }
    
    public void execute(String code){                
        try {
            //analyzer.viewTokensSequence(true);
            //analyzer.viewContextFreeGrammar(true);
            //analyzer.viewSyntacticTable(true);
            analyzer.scanner(new StringBuffer(code));
            analyzer.parse();
            analyzer.getAppender().println("C�DIGO SQL V�LIDO");
        }
        catch(Exception e){
            analyzer.getAppender().println("C�DIGO SQL INV�LIDO\n"+e.getClass()+": "+e.getMessage());
        }        
    }
}
