/*
 * CodigoFonte.java
 *
 * Created on 9 de Novembro de 2007, 10:53
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

/**
 *
 * @author Administrador
 */
public interface NodoExemplo {
    public int totalFilhos();
    public NodoExemplo getFilho(int indice);
    public String getCodigoFonte() throws Exception;
    public boolean eDiretorio();
    public boolean eArquivo();
}
