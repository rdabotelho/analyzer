/*
 * MyTreeModel.java
 *
 * Created on 2 de Novembro de 2007, 15:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

import javax.swing.tree.DefaultTreeModel;

/**
 *
 * @author Raimundo Botelho
 */
public class MyTreeModel extends DefaultTreeModel {
    
    private NodoExemplo root;
    
    /** Creates a new instance of MyTreeModel */
    public MyTreeModel(NodoExemplo root) {
        super(null);
        this.root = root;
    }

    public Object getChild(Object parent, int index) {
        return ((NodoExemplo)parent).getFilho(index);
    }

    public int getChildCount(Object parent) {
        return ((NodoExemplo)parent).totalFilhos();
    }

    public int getIndexOfChild(Object parent, Object child) {
        NodoExemplo pai = (NodoExemplo)parent;
        for(int i=0; i<pai.totalFilhos(); i++)
            if(pai.getFilho(i) == child)
                return i;
        return -1;
    }

    public Object getRoot() {
        return root;
    }

    public boolean isLeaf(Object node) {
        return ((NodoExemplo)node).eArquivo();
    }                
}
