/*
 * NodoExemploImpl.java
 *
 * Created on 9 de Novembro de 2007, 11:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

/**
 *
 * @author Administrador
 */
public class NodoExemploJar implements NodoExemplo {
    
    private JarFile jarFile;
    private NodoExemploJar pai;
    private List<NodoExemploJar> filhos;
    private String nomeFolha;
    private String nome;
    
    /** Creates a new instance of NodoExemploImpl */
    public NodoExemploJar(NodoExemploJar pai,JarFile jarFile,String nome,String nomeFolha) {
        this.pai = pai;
        if(this.pai != null)
            this.pai.adicionarFilho(this);
        this.jarFile = jarFile;
        this.nome = nome;
        this.nomeFolha = nomeFolha;
        this.filhos = new LinkedList<NodoExemploJar>();
    }
    
    public int totalFilhos(){
        return filhos.size();
    }
    
    public NodoExemplo getFilho(int indice){
        return filhos.get(indice);
    }
    
    public String getCodigoFonte() throws Exception{
        ZipEntry zipEntry = jarFile.getEntry(nome);        
        byte[] dados = new byte[(int)zipEntry.getSize()];
        InputStream in = jarFile.getInputStream(jarFile.getEntry(nome));
        in.read(dados);
        in.close();
        return new String(dados);
    }
    
    public boolean eDiretorio(){
        return jarFile.getEntry(nome).isDirectory();
    }
    
    public boolean eArquivo(){
        return !jarFile.getEntry(nome).isDirectory();
    }   
    
    public String toString(){
        return this.nomeFolha;
    }    
    
    public boolean adicionarFilho(NodoExemploJar filho){
        return filhos.add(filho);
    }
}
