/*
 * NodoExemploImpl.java
 *
 * Created on 9 de Novembro de 2007, 11:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.rim.sqlanalyzer.ide;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;

/**
 *
 * @author Administrador
 */
public class NodoExemploFile implements NodoExemplo {
    
    private File file;
    
    /** Creates a new instance of NodoExemploImpl */
    public NodoExemploFile(File file) {
        this.file = file;
    }
    
    public int totalFilhos(){
        return file.listFiles().length;
    }
    
    public NodoExemplo getFilho(int indice){
        return new NodoExemploFile(file.listFiles()[indice]);
    }
    
    public String getCodigoFonte() throws Exception{
        byte[] dados = new byte[(int)file.length()];
        FileInputStream in =  new FileInputStream(file); 
        in.read(dados);
        in.close();
        return new String(dados);
    }
    
    public boolean eDiretorio(){
        return file.isDirectory();
    }
    
    public boolean eArquivo(){
        return file.isFile();        
    }   
    
    public String toString(){
        return file.getName();
    }    
}
