/*
	Uma vez feita essa opera��o
	a tabela e todos os dados dela
	ser�o perdidos
*/
DROP TABLE cidades