/* cuidado ao fazer isso */
DELETE FROM CLIENTES