select c.codigo,c.nome,c.bairro,c.cidade
from clientes c
where c.status = 'ativo'